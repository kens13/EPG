# -*- coding: utf-8 -*-


import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import os, sys, json, urllib, urllib2, base64

from config import mac_based, token_type

from tools import addondir
from tools import get_string
from tools import fileExpired

reload(sys)
sys.setdefaultencoding('utf8')



def m3u_create():
	
	from pvr import epg_sources, epg_src
	from tools import get_localhost

	from stalker import get_genres, get_channels
	from stalker import fm3u, fadult
	
	from config import adult_ok, is_protected, key_passed

	try:
		epg_ref = epg_sources.index(epg_src)
		url = [
			'https://raw.githubusercontent.com/kens13/EPG/master/stalker_kens.json',
			'https://raw.githubusercontent.com/kens13/EPG/master/stalker_kens.json'
		][epg_ref]
	
	except:
		url = None
	
	try: epg = json.loads(urllib2.urlopen(url).read())
	except: epg = {}
	
	genres = get_genres()
	channels = get_channels()
	
	cats = {}
	for genre, id in genres:
		cats[id] = genre
		
	ip, port, host = get_localhost()
		
	m3u = '#EXTM3U\n\n'
	
	adult = ''
	
	#link_type = token_type if mac_based else 0
	#link_type = token_type
	link_type = 1 if adult_ok and is_protected else (token_type if mac_based else 0)
	
	for ch_num, name, id, cat, icon, url, tmp in channels:
		name = name.encode("utf-8")
		alias = name.replace(' ', ' ')
		
		is_adult = any (item in cat.lower() for item in ['adult', '13'])
		
		ch_name = '*?'+name if is_adult and adult_ok and is_protected else name
		ch_title = '[COLOR yellow]'+name+'[/COLOR]' if is_adult and adult_ok else name
		
		link = [
			url.split()[-1],
			host+'/play?channel='+urllib.quote_plus(ch_name)
		]
		
		try: epg_id = epg[name]
		except: epg_id = ''
		
		line = '#EXTINF:-1 tvg-id="'+epg_id+'" tvg-name="'+alias+'" tvg-logo="'+icon+'" group-title="'+cats[cat]+'", '+ch_title+'\n'
		line += link[link_type] + '\n\n'
		
		if is_adult: adult += line
		else: m3u += line
	
	if adult_ok: m3u += adult
	
	with open(fm3u, 'w') as f: f.write(m3u)
	
	return fm3u
	
	
	

def m3u_read(acc, fcat, fchannel, fvod):
	from stalker import exp_iptv
	from config import foreign_channel, foreign_ch_num

	try: id, password, server = acc
	except: return [None, None, None]
	
	if not fileExpired(fchannel, exp_iptv):
		all_caches = []
		try:
			for fcache in [fcat, fchannel, fvod]:
				with open(fcache, 'r') as f: cache = f.read()
				valid = all (item in cache for item in acc) or (fcache == fcat)
				if not valid: valid = 1 / 0
				all_caches.append(json.loads(cache))
			return all_caches
		except:
			pass

	url = 'http://'+server+':80/get.php?username='+id+'&password='+password+'&type=m3u_plus&output=ts'

	try:
		M3U = urllib2.urlopen(url).read()
	except:
		M3U = None
		
	if not M3U: return [None, None, None]
	
	try: data = M3U.split('#EXTINF:')[1:]
	except: data = None
	
	if not data: return [None, None, None]
	
	tmp = '0'
	num = 0
	meta = None
	cats = []
	channels = []
	vod = []
	
	for i in data:
		i = ' '.join(i.split())
		if not i: continue
		
		url = i.split()[-1]
		name = ' '.join(','.join(i.split(',')[1:]).replace(url, '').split())
		
		if (name == foreign_channel): num = foreign_ch_num
		else: num += 1
		
		try: icon = get_string('tvg-logo="', '"', i)[0]
		except: icon = ''
		
		try: id = int(icon.split('/')[-1].split('.')[0])
		except: id = num
		
		try: cat = get_string('group-title="', '"', i)[0] 
		except: cat = None
		if not cat: cat = 'Uncategorized'
		
		if ('/movie/' in url.lower()) or (cat.lower() == 'movies'):
			vod.append([name, icon, url, meta])
		else:
			channels.append([num, name, id, cat, icon, url, tmp])
			if cat not in cats: cats.append(cat)
		
	cats = [["All", "*"]]+[[cat, cat] for cat in sorted(cats)]
	
	caches = [[cats,fcat], [channels,fchannel], [vod, fvod]]
	for cache, fcache in caches:
		js = json.dumps(cache)
		with open(fcache, 'w') as f: f.write(js)
	
	m3u_create()
	
	return [cats, channels, vod]
	
